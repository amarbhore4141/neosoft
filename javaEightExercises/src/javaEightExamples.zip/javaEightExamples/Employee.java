package javaEightExamples;

public class Employee {
}
