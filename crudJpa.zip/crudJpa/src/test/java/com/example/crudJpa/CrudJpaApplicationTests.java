package com.example.crudJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
