package com.example.crudJpa.dto;

import lombok.*;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SkillsDto {
    private String skillName;
    private String skillLevel;
}
